/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: [
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          '"Segoe UI"',
          'Roboto',
          'Helvetica',
          'Arial',
          'sans-serif'
        ],
      },
      colors: {
        primary: {
          light: '#30313D',
          dark: '#E2E8F0',
        },
        secondary: {
          light: '#687385',
          dark: '#94A3B8',
        },
        accent: '#635BFF',
        'code-bg': '#0A2540',
        'pane-bg': '#1A1F36',
        border: {
          light: '#E6E6E6',
          dark: '#334155',
        },
      },
    },
  },
  plugins: [],
}
