import React, { useState, useEffect, createContext } from 'react';
import Markdoc from '@markdoc/markdoc';
import { Layout } from './components/Layout';
import { MainContent } from './components/MainContent';
import { ChatbotPane } from './components/ChatbotPane';
import { MockSentryErrorBoundary } from './components/MockSentryErrorBoundary';
import { config as markdocConfig } from './markdoc.config';
import rawMarkdown from './content/demo.md?raw';

// Global AppContext to bind interactive elements (Chatbot, LLM copying, Markdown view)
export const AppContext = createContext({
  isChatOpen: false,
  setIsChatOpen: () => {},
  chatContext: '',
  setChatContext: () => {},
  setViewMode: () => {}
});

export default function App() {
  const [activeId, setActiveId] = useState('intro');
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // Chatbot drawer toggle & context reference pill
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatContext, setChatContext] = useState('');

  // Toggle view state ('docs' vs 'markdown') based on initial URL path
  const [viewMode, setViewMode] = useState(() => 
    window.location.pathname.endsWith('.md') ? 'markdown' : 'docs'
  );

  // Synchronize URL and browser back/forward buttons
  useEffect(() => {
    const handlePopState = () => {
      const isMd = window.location.pathname.endsWith('.md');
      setViewMode(isMd ? 'markdown' : 'docs');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Initialize theme globally from localStorage or system preference
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDarkMode(false);
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleTheme = () => {
    if (isDarkMode) {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
      setIsDarkMode(false);
    } else {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
      setIsDarkMode(true);
    }
  };

  // Lock body background to #0E1117 in Markdown View Mode to resolve overscroll white background bounce
  useEffect(() => {
    if (viewMode === 'markdown') {
      const originalBg = document.body.style.backgroundColor;
      document.body.style.backgroundColor = '#0E1117';
      return () => {
        document.body.style.backgroundColor = originalBg;
      };
    }
  }, [viewMode]);

  // Update browser URL query strings on view toggles
  const changeViewMode = (mode) => {
    setViewMode(mode);
    if (mode === 'markdown') {
      window.history.pushState({}, '', '/api.md?lang=curl');
    } else {
      window.history.pushState({}, '', '/');
    }
  };

  // Parse and transform Markdoc templates
  const ast = Markdoc.parse(rawMarkdown);
  const renderableAst = Markdoc.transform(ast, markdocConfig);

  // Monospace Markdown Editor view (api.md mode)
  if (viewMode === 'markdown') {
    return (
      <div className="h-screen overflow-y-auto bg-[#0E1117] text-[#E2E8F0] p-6 md:p-12 font-mono text-[13px] leading-relaxed whitespace-pre-wrap select-text selection:bg-accent/35 w-full">
        {/* Sticky floating button to toggle back to docs layout */}
        <div className="fixed top-4 right-4 z-50">
          <button
            onClick={() => changeViewMode('docs')}
            className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#161920] border border-slate-800 rounded hover:border-slate-700 text-slate-300 hover:text-white transition-all text-xs font-sans font-bold shadow-lg"
          >
            <span>Back to API Reference</span>
            <span>→</span>
          </button>
        </div>
        <div className="max-w-3xl mx-auto py-4 select-text">
          {rawMarkdown}
        </div>
      </div>
    );
  }

  // Normal three-pane layout view
  return (
    <AppContext.Provider value={{ isChatOpen, setIsChatOpen, chatContext, setChatContext, setViewMode: changeViewMode }}>
      <MockSentryErrorBoundary>
        <Layout
          currentActiveId={activeId}
          setActiveId={setActiveId}
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          isChatOpen={isChatOpen}
        >
          <MainContent renderableAst={renderableAst} />
        </Layout>

        {/* Floating slide-out chatbot pane */}
        <ChatbotPane
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          context={chatContext}
          clearContext={() => setChatContext('')}
        />
      </MockSentryErrorBoundary>
    </AppContext.Provider>
  );
}
