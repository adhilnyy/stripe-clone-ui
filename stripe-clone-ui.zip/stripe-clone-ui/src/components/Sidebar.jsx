import React, { useState, useEffect } from 'react';
import { Search, Sun, Moon, X, ChevronDown, ChevronRight, Sparkles, BookOpen, Key, AlertOctagon, RefreshCw, HelpCircle } from 'lucide-react';

const GETTING_STARTED_ITEMS = [
  { id: 'intro', label: 'Introduction' },
  { id: 'auth', label: 'Authentication' },
  { id: 'errors', label: 'Errors' },
  { id: 'expanding-responses', label: 'Expanding Responses' },
  { id: 'idempotency', label: 'Idempotent requests' },
  { id: 'include-dependent', label: 'Include-dependent response values (API v2)' },
  { id: 'metadata', label: 'Metadata' },
  { id: 'pagination', label: 'Pagination' },
  { id: 'request-ids', label: 'Request IDs' },
  { id: 'connected-accounts', label: 'Connected Accounts' },
  { id: 'versioning', label: 'Versioning' },
];

const CORE_RESOURCES_ITEMS = [
  { id: 'accounts-v2', label: 'Accounts v2' },
  { id: 'account-links-v2', label: 'Account Links v2' },
  { id: 'account-tokens-v2', label: 'Account Tokens v2' },
  { id: 'balance', label: 'Balance' },
  { id: 'balance-transactions', label: 'Balance Transactions' },
  { id: 'charges', label: 'Charges' },
  { id: 'customers', label: 'Customers' },
  { id: 'customer-session', label: 'Customer Session' },
  { id: 'disputes', label: 'Disputes' },
  { id: 'events', label: 'Events' },
  { id: 'events-v2', label: 'Events v2' },
  { id: 'event-destinations-v2', label: 'Event Destinations v2' },
  { id: 'files', label: 'Files' },
  { id: 'file-links', label: 'File Links' },
  { id: 'mandates', label: 'Mandates' },
  { id: 'refunds', label: 'Refunds' },
];

export function Sidebar({ isOpen, setIsOpen, currentActiveId, onNavClick, isDarkMode, toggleTheme, onAskAiClick }) {
  const [coreOpen, setCoreOpen] = useState(true);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Keyboard shortcut listener (⌘K / Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Open search on slash or ctrl/meta K
      if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
        e.preventDefault();
        setSearchOpen(true);
      } else if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      } else if (e.key === 'Escape') {
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // List of searchable sections derived from sidebar navigation
  const allSearchableItems = [
    ...GETTING_STARTED_ITEMS.map(i => ({ ...i, category: 'Getting Started' })),
    ...CORE_RESOURCES_ITEMS.map(i => ({ ...i, category: 'Core Resources' }))
  ];

  const filteredSearch = allSearchableItems.filter(item =>
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSearchResultClick = (id) => {
    setSearchOpen(false);
    setSearchQuery('');
    onNavClick(id);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile background overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-slate-950/50 backdrop-blur-sm lg:hidden transition-opacity duration-200"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Main Sidebar Wrapper */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 flex flex-col w-[285px] border-r border-border-light dark:border-[#1F293D] bg-[#F8F9FA] dark:bg-[#0C0E12] transition-all duration-300 transform lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:sticky lg:h-screen lg:top-0 select-none`}
      >
        {/* Brand & Theme Toggle Section */}
        <div className="flex items-center justify-between px-6 py-[18px] border-b border-border-light dark:border-[#1F293D]">
          <a href="/" className="flex items-center gap-1.5 hover:opacity-85 transition-opacity">
            {/* Stripe Logo Wordmark */}
            <svg className="h-5 w-12 flex-shrink-0" viewBox="0 0 360 150" xmlns="http://www.w3.org/2000/svg">
              <path className="fill-[#0A2540] dark:fill-white transition-colors" fillRule="evenodd" d="M360 77.4c0 2.4-.2 7.6-.2 8.9h-48.9c1.1 11.8 9.7 15.2 19.4 15.2 9.9 0 17.7-2.1 24.5-5.5v20c-6.8 3.8-15.8 6.5-27.7 6.5-24.4 0-41.4-15.2-41.4-45.3 0-25.4 14.4-45.6 38.2-45.6 23.7 0 36.1 20.2 36.1 45.8zm-49.4-9.5h25.8c0-11.3-6.5-16-12.6-16-6.3 0-13.2 4.7-13.2 16zm-63.5-36.3c17.5 0 34 15.8 34.1 44.8 0 31.7-16.3 46.1-34.2 46.1-8.8 0-14.1-3.7-17.7-6.3l-.1 28.3-25 5.3V33.2h22l1.3 6.2c3.5-3.2 9.8-7.8 19.6-7.8zm-6 68.9c9.2 0 15.4-10 15.4-23.4 0-13.1-6.3-23.3-15.4-23.3-5.7 0-9.3 2-11.9 4.9l.1 37.1c2.4 2.6 5.9 4.7 11.8 4.7zm-71.3-74.8V5.3L194.9 0v20.3l-25.1 5.4zm0 7.6h25.1v87.5h-25.1V33.3zm-26.9 7.4c5.9-10.8 17.6-8.6 20.8-7.4v23c-3.1-1.1-13.1-2.5-19 5.2v59.3h-25V33.3h21.6l1.6 7.4zm-50-29.1l-.1 21.7h19v21.3h-19v35.5c0 14.8 15.8 10.2 19 8.9v20.3c-3.3 1.8-9.3 3.3-17.5 3.3-14.8 0-25.9-10.9-25.9-25.7l.1-80.1 24.4-5.2zM25.3 58.7c0 11.2 38.1 5.9 38.2 35.7 0 17.9-14.3 28.2-35.1 28.2-8.6 0-18-1.7-27.3-5.7V93.1c8.4 4.6 19 8 27.3 8 5.6 0 9.6-1.5 9.6-6.1 0-11.9-38-7.5-38-35.1 0-17.7 13.5-28.3 33.8-28.3 8.3 0 16.5 1.3 24.8 4.6v23.5c-7.6-4.1-17.2-6.4-24.8-6.4-5.3 0-8.5 1.5-8.5 5.4z" />
            </svg>
            
            {/* API Wordmark */}
            <svg className="h-2.5 w-6 flex-shrink-0" viewBox="0 0 260 113" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path className="fill-[#635BFF] dark:fill-[#8F85FF]" d="M42.056 0.991992L0.248 113H23.024L31.916 88.976H78.092L86.984 113H110.228L68.264 0.991992H42.056ZM54.848 26.42L70.76 69.476H39.092L54.848 26.42ZM150.43 71.816H173.362C199.102 71.816 215.17 59.492 215.17 36.404C215.17 13.16 199.102 0.991992 173.362 0.991992H127.498V113H150.43V71.816ZM150.43 52.316V20.492H172.114C185.53 20.492 192.394 26.264 192.394 36.404C192.394 46.388 185.53 52.316 172.114 52.316H150.43ZM259.423 0.991992H236.491V113H259.423V0.991992Z" />
            </svg>
          </a>

          <div className="flex items-center gap-2.5">
            {/* Sliding Toggle Switch for Theme */}
            <button
              onClick={toggleTheme}
              className="relative w-9 h-5 rounded-full bg-slate-200 dark:bg-slate-800 transition-colors duration-250 flex items-center shadow-inner focus:outline-none cursor-pointer"
            >
              <div 
                className={`absolute w-5 h-5 rounded-full bg-white dark:bg-[#1A1F36] shadow-md flex items-center justify-center transition-all duration-200 border border-slate-250/60 dark:border-slate-700/60 ${
                  isDarkMode ? 'left-4' : 'left-0'
                }`}
              >
                {isDarkMode ? (
                  <Moon className="w-3.5 h-3.5 text-indigo-500 fill-indigo-500" />
                ) : (
                  <Sun className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                )}
              </div>
            </button>

            <button 
              className="p-1 rounded lg:hidden text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800"
              onClick={() => setIsOpen(false)}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search controls row (Find anything + Ask AI) */}
        <div className="px-4 py-3.5 flex gap-2 border-b border-border-light dark:border-[#1F293D] select-none">
          <button
            onClick={() => setSearchOpen(true)}
            className="flex-1 flex items-center justify-between px-3 py-1.5 text-[13px] font-sans font-medium text-slate-600 dark:text-slate-455 bg-[#F0F3F6] dark:bg-[#161920] border border-[#D8E2EC] dark:border-slate-800 rounded-xl hover:bg-[#E2E7ED] dark:hover:bg-slate-800/80 transition-all duration-150 text-left shadow-none cursor-pointer focus:outline-none"
          >
            <div className="flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-slate-550 dark:text-slate-450" />
              <span>Find anything</span>
            </div>
            <kbd className="px-1.5 py-0.5 text-[10px] font-sans font-medium bg-white dark:bg-slate-850 text-slate-500 dark:text-slate-450 border border-[#D8E2EC] dark:border-slate-700/60 rounded-md">
              /
            </kbd>
          </button>

          <button
            onClick={onAskAiClick}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-[13px] font-sans font-semibold text-slate-700 dark:text-slate-300 bg-[#F0F3F6] dark:bg-[#161920] border border-[#D8E2EC] dark:border-slate-800 hover:bg-[#E2E7ED] dark:hover:bg-slate-800/80 rounded-xl transition-all duration-150 shadow-none cursor-pointer focus:outline-none"
          >
            <Sparkles className="w-3.5 h-3.5 text-slate-550 dark:text-slate-450" />
            <span>Ask AI</span>
          </button>
        </div>

        {/* Navigation lists */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-4 scrollbar-thin scrollbar-thumb-slate-800">
          
          {/* Section 1: Getting Started */}
          <ul className="space-y-0.5">
            {GETTING_STARTED_ITEMS.map((item) => {
              const isActive = currentActiveId === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      onNavClick(item.id);
                      setIsOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 text-[13px] font-sans rounded-md transition-all duration-150 ${
                      isActive
                        ? 'bg-[#635BFF]/10 text-[#635BFF] dark:bg-[#635BFF]/15 dark:text-[#8F85FF] font-semibold font-sans'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-850 dark:hover:text-slate-200 hover:bg-slate-200/40 dark:hover:bg-slate-900/40 font-sans'
                    }`}
                  >
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>

          {/* Section 2: Accordion Core Resources */}
          <div className="space-y-0.5">
            <button
              onClick={() => setCoreOpen(!coreOpen)}
              className="w-full flex items-center justify-between px-3 py-2 text-[13px] font-sans font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider hover:text-slate-700 dark:hover:text-slate-200"
            >
              <span>Core Resources</span>
              {coreOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>

            {coreOpen && (
              <ul className="pl-2 space-y-0.5 border-l border-slate-200 dark:border-slate-800/80 ml-3">
                {CORE_RESOURCES_ITEMS.map((item) => {
                  const isActive = currentActiveId === item.id;
                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => {
                          onNavClick(item.id);
                          setIsOpen(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 text-[13px] font-sans rounded-md transition-all duration-150 ${
                          isActive
                            ? 'bg-[#635BFF]/10 text-[#635BFF] dark:bg-[#635BFF]/15 dark:text-[#8F85FF] font-semibold font-sans'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-850 dark:hover:text-slate-200 hover:bg-slate-200/40 dark:hover:bg-slate-900/40 font-sans'
                        }`}
                      >
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </nav>

        {/* Sidebar Version Footer */}
        <div className="px-5 py-3.5 border-t border-border-light dark:border-[#1F293D] flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500">
          <span>Stripe API Docs</span>
          <span>v2.88.0</span>
        </div>
      </aside>

      {/* Algolia Search modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" onClick={() => setSearchOpen(false)} />
          
          <div className="relative z-10 w-full max-w-lg bg-white dark:bg-[#161920] border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border-light dark:border-border-dark">
              <Search className="w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Find anything..."
                className="flex-1 bg-transparent text-sm text-slate-800 dark:text-slate-200 outline-none placeholder-slate-400"
                autoFocus
              />
              <button onClick={() => setSearchOpen(false)} className="p-1 text-slate-450 hover:text-slate-600 dark:hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-[300px] overflow-y-auto p-2">
              {filteredSearch.length > 0 ? (
                <div className="space-y-0.5">
                  {filteredSearch.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleSearchResultClick(item.id)}
                      className="w-full text-left p-3.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors flex items-center justify-between group"
                    >
                      <div>
                        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-200 group-hover:text-accent font-sans">
                          {item.label}
                        </h4>
                        <span className="text-[10px] text-slate-400 font-sans uppercase">
                          {item.category}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-sm text-slate-450 dark:text-slate-500 font-sans">
                  No matches found for "{searchQuery}"
                </div>
              )}
            </div>
            
            <div className="px-4 py-2 bg-slate-50 dark:bg-[#0C0E12] border-t border-border-light dark:border-border-dark text-[10px] text-slate-400 flex justify-between select-none">
              <span>Find anything Search</span>
              <span>ESC to close</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
