import React from 'react';
import Markdoc from '@markdoc/markdoc';
import { 
  Section, 
  Endpoint, 
  Parameter, 
  Callout, 
  CodeBlock, 
  BaseUrl, 
  ClientLibraries, 
  StatusCodes, 
  ErrorTypes, 
  AttributesHeader,
  Feedback,
  RightPane,
  InfoCard,
  CollapsibleParameters
} from './CustomTags';

// React components map corresponding to the Markdoc render config
const components = {
  Section,
  Endpoint,
  Parameter,
  Callout,
  CodeBlock,
  BaseUrl,
  ClientLibraries,
  StatusCodes,
  ErrorTypes,
  AttributesHeader,
  Feedback,
  RightPane,
  InfoCard,
  CollapsibleParameters
};

export function MainContent({ renderableAst }) {
  if (!renderableAst) {
    return (
      <div className="p-8 text-center text-slate-500 font-sans">
        No content loaded.
      </div>
    );
  }

  // Render transformed Markdoc AST to React elements
  return (
    <div className="w-full h-full relative font-sans">
      {Markdoc.renderers.react(renderableAst, React, { components })}
    </div>
  );
}
