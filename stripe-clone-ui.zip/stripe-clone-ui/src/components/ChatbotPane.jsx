import React, { useState, useEffect, useRef } from 'react';
import { X, Plus, Maximize2, ArrowUp, Bot, User, ChevronDown, Sparkles } from 'lucide-react';
import lodash from 'lodash';

// Preset chatbot responses based on keywords
const RESPONSES = {
  auth: `**Authentication** in Stripe is managed via API keys:
- **Secret Keys:** Prefix \`sk_test_\` (test mode) or \`sk_live_\` (live mode).
- **Restricted Keys:** Prefix \`rk_live_\`, granting selective permissions (e.g. only read charges). Recommended for production!
- All requests must use **HTTPS**; standard HTTP calls are blocked.
\`\`\`bash
curl https://api.stripe.com/v1/charges \\
  -u sk_test_tR3Pybc...96tH8BS4VQ2u:
\`\`\``,
  charge: `To charge a credit or debit card, you create a **Charge** resource:
- **Required parameters:** \`amount\` (integer in smallest currency unit, e.g. 2000 for $20.00) and \`currency\` (e.g., \`usd\`).
- **Optional parameters:** \`customer\` ID and \`description\`.
- Charge objects return capture flags, receipt URLs, and capture statuses (\`succeeded\`, \`failed\`).
\`\`\`javascript
const charge = await stripe.charges.create({
  amount: 2000,
  currency: 'usd',
  description: 'Software subscription',
});
\`\`\``,
  customer: `The **Customer** resource allows you to store payment details for recurring subscriptions or future payments:
- **Create Customer:** POST \`/v1/customers\`.
- Pass \`email\`, \`name\`, and \`description\` to describe the client.
- The returned \`id\` (e.g. \`cus_9s8dfyhsdf\`) can be bound to charges or billing schedules.`,
  error: `Stripe uses HTTP response codes to classify **Errors**:
- **2xx:** Success.
- **4xx:** Request failed (e.g., missing required fields, card declines).
- **5xx:** Server issues (extremely rare).
- **Common Error Types:**
  - \`api_error\`: Stripe backend glitches.
  - \`card_error\`: User card declined.
  - \`invalid_request_error\`: Bad parameters.
  - \`idempotency_error\`: Duplicate key mismatch.`,
  default: `I'm your Stripe AI Assistant. You can ask me questions about:
- **Authentication:** API keys, secret prefixes, and HTTPS security.
- **Charges:** Creating credit card transactions.
- **Customers:** Managing user records.
- **Errors:** Status codes and programmatic card declines.

How can I help you with your Stripe integration today?`
};

export function ChatbotPane({ isOpen, onClose, context, clearContext }) {
  const [messages, setMessages] = useState([
    {
      sender: 'ai',
      text: RESPONSES.default,
      timestamp: new Date()
    }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  // Scroll to bottom when messages list changes
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputVal.trim()) return;

    const userText = inputVal;
    const userMsg = {
      sender: 'user',
      text: userText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      let replyText = RESPONSES.default;
      const lowerText = userText.toLowerCase();

      if (lowerText.includes('auth') || lowerText.includes('key')) {
        replyText = RESPONSES.auth;
      } else if (lowerText.includes('charge') || lowerText.includes('pay')) {
        replyText = RESPONSES.charge;
      } else if (lowerText.includes('customer') || lowerText.includes('user')) {
        replyText = RESPONSES.customer;
      } else if (lowerText.includes('error') || lowerText.includes('decline') || lowerText.includes('status')) {
        replyText = RESPONSES.error;
      }

      setMessages(prev => [...prev, {
        sender: 'ai',
        text: replyText,
        timestamp: new Date()
      }]);
      setIsTyping(false);
    }, 850);
  };

  const handleReset = () => {
    setMessages([
      {
        sender: 'ai',
        text: RESPONSES.default,
        timestamp: new Date()
      }
    ]);
    clearContext();
  };

  if (!isOpen) return null;

  return (
    <div className="w-full lg:w-[400px] h-screen border-l border-slate-200 dark:border-[#1F293D] bg-white dark:bg-[#0E1117] flex flex-col fixed top-0 right-0 z-40 transition-all duration-300 shadow-2xl animate-in slide-in-from-right font-sans">
      
      {/* Chat Pane Header */}
      <div className="flex items-center justify-between px-4 py-[15px] border-b border-border-light dark:border-[#1F293D]">
        <button 
          onClick={() => alert("Creating/opening a different mock chat thread...")}
          className="flex items-center gap-1 text-[13px] font-semibold text-slate-800 dark:text-slate-200 hover:opacity-80"
        >
          <Sparkles className="w-4 h-4 text-accent" />
          <span>New chat</span>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
        </button>

        <div className="flex items-center gap-3.5 text-slate-450 dark:text-slate-500">
          <button onClick={handleReset} title="Reset Chat" className="hover:text-slate-800 dark:hover:text-white">
            <Plus className="w-4.5 h-4.5" />
          </button>
          <button onClick={() => alert("Expanding panel (mock)...")} title="Expand" className="hover:text-slate-800 dark:hover:text-white">
            <Maximize2 className="w-4 h-4" />
          </button>
          <button onClick={onClose} title="Close Pane" className="hover:text-slate-800 dark:hover:text-white">
            <X className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>

      {/* AI Warning banner */}
      <div className="px-4 py-2 bg-[#F8F9FA] dark:bg-[#161920]/40 border-b border-slate-100 dark:border-[#1F293D]/50 text-[10px] text-center text-slate-400 dark:text-slate-500 font-medium select-none">
        Responses are generated using AI and may contain mistakes.
      </div>

      {/* Messages Scrollbox */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 bg-white dark:bg-[#0E1117] scrollbar-thin"
      >
        {messages.map((msg, idx) => (
          <div 
            key={idx} 
            className={`flex gap-3 max-w-[85%] ${
              msg.sender === 'user' ? 'ml-auto flex-row-reverse text-right' : 'text-left'
            }`}
          >
            {/* Avatar */}
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs flex-shrink-0 select-none ${
              msg.sender === 'user' 
                ? 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-350' 
                : 'bg-accent/15 text-accent'
            }`}>
              {msg.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
            </div>

            {/* Message Body */}
            <div className={`p-3 rounded-lg text-xs leading-relaxed font-sans ${
              msg.sender === 'user'
                ? 'bg-accent text-white rounded-tr-none'
                : 'bg-[#F8F9FA] dark:bg-[#161920] text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-150 dark:border-slate-800/40'
            }`}>
              <div className="whitespace-pre-wrap whitespace-normal break-words select-text">
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        
        {/* Typing Loader animation */}
        {isTyping && (
          <div className="flex gap-3 max-w-[80%] text-left">
            <div className="w-7 h-7 rounded-full bg-accent/15 text-accent flex items-center justify-center flex-shrink-0">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div className="p-3 bg-[#F8F9FA] dark:bg-[#161920] text-slate-400 rounded-lg rounded-tl-none border border-slate-150 dark:border-slate-800/40 flex items-center gap-1.5 py-2">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
      </div>

      {/* Input & Footer Controls */}
      <div className="p-4 border-t border-border-light dark:border-[#1F293D] bg-white dark:bg-[#0E1117] flex flex-col gap-2">
        
        <div className="text-[11px] text-slate-400 dark:text-slate-500 font-sans leading-none">
          Ask questions about Stripe and get help with your integration.
        </div>

        <div className="text-[10px] text-slate-450 dark:text-slate-600 font-mono select-none">
          Tip: you can toggle this pane with <kbd className="px-1 py-0.2 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded font-sans font-bold">⌘ + I</kbd>
        </div>

        {/* Context Reference Pill */}
        {context && (
          <div className="flex items-center justify-between px-2.5 py-1 bg-accent/5 border border-accent/15 rounded text-[11px] text-accent dark:text-[#A78BFA] font-mono select-none w-fit max-w-full">
            <span className="truncate mr-2">https://docs.stripe.com/api{context}</span>
            <button onClick={clearContext} className="hover:text-slate-800 dark:hover:text-white">
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Input box form */}
        <div className="relative mt-1.5 border border-slate-200 dark:border-slate-800/80 focus-within:border-accent dark:focus-within:border-accent bg-slate-50 dark:bg-[#161920] rounded-xl p-2.5 flex flex-col min-h-[90px] transition-all">
          <textarea
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask a question about the page"
            className="w-full flex-1 bg-transparent text-slate-700 dark:text-white text-xs outline-none resize-none placeholder-slate-400 dark:placeholder-slate-500 leading-relaxed font-sans pr-8"
          />
          <div className="absolute right-2.5 bottom-2.5">
            <button
              onClick={handleSend}
              className="p-1.5 rounded-full bg-accent text-white hover:bg-opacity-90 active:scale-95 transition-all shadow-md"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
