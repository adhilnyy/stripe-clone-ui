import React from 'react';
import * as Sentry from '@sentry/react';
import { AlertCircle } from 'lucide-react';

function ErrorFallback({ error, resetError }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center bg-white dark:bg-slate-900 border border-border-light dark:border-border-dark rounded-xl m-6 shadow-md transition-colors duration-200">
      <AlertCircle className="w-12 h-12 text-rose-500 mb-4 animate-bounce" />
      <h3 className="text-lg font-bold text-[#30313D] dark:text-slate-100 mb-2 font-sans">
        Something went wrong
      </h3>
      <p className="text-sm text-[#687385] dark:text-slate-400 max-w-md mb-6 font-sans">
        An error occurred while loading this section of the API reference. The event has been logged to Sentry.
      </p>
      {error && (
        <pre className="text-left text-xs font-mono bg-slate-50 dark:bg-slate-950 p-4 rounded border border-border-light dark:border-border-dark text-rose-600 dark:text-rose-400 overflow-auto max-w-lg mb-6 max-h-[150px] w-full">
          {error.toString()}
        </pre>
      )}
      <button
        onClick={resetError}
        className="px-4 py-2 bg-accent text-white rounded-md text-sm font-semibold hover:bg-opacity-90 active:scale-95 transition-all duration-150 shadow-md shadow-accent/20"
      >
        Reload Component
      </button>
    </div>
  );
}

export function MockSentryErrorBoundary({ children }) {
  return (
    <Sentry.ErrorBoundary
      fallback={({ error, resetError }) => (
        <ErrorFallback error={error} resetError={resetError} />
      )}
    >
      {children}
    </Sentry.ErrorBoundary>
  );
}
