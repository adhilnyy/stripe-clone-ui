import React, { useState, useEffect, useRef, useContext } from 'react';
import Prism from 'prismjs';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-ruby';
import 'prismjs/components/prism-go';
import 'prismjs/components/prism-json';
import { Info, AlertTriangle, Check, Copy, MessageSquare, FileText, Terminal, ExternalLink, ChevronRight, ChevronDown, Sparkles } from 'lucide-react';
import { AppContext } from '../App';

// High-fidelity Markdown text copied for LLMs based on section ID
const SECTION_MARKDOWNS = {
  intro: `# API Reference

The Stripe API is organized around [REST](http://en.wikipedia.org/wiki/Representational_State_Transfer). Our API has predictable resource-oriented URLs, accepts [form-encoded](https://en.wikipedia.org/wiki/POST_\\(HTTP\\)#Use_for_submitting_web_forms) request bodies, returns [JSON-encoded](http://www.json.org/) responses, and uses standard HTTP response codes, authentication, and verbs.

You can use the Stripe API in [sandboxes](https://docs.stripe.com/sandboxes.md) without affecting your live data or interacting with banking networks. The API key that you use to [authenticate](https://docs.stripe.com/api/authentication.md) the request determines whether the request runs in live mode or in a sandbox. Sandboxes support all v2 APIs. Test mode sandboxes support some [v2 APIs](https://docs.stripe.com/testing-use-cases.md#compare).

The Stripe API doesn’t support bulk updates. You can work on only one object per request.

The Stripe API differs for every account as we release new [versions](https://docs.stripe.com/api/versioning.md) and tailor functionality. Log in to see docs with your test key and data.

## Just getting started?

Check out our [development quickstart](https://docs.stripe.com/get-started/development-environment.md) guide.

## Not a developer?

Use Stripe’s [no-code options](https://docs.stripe.com/payments/no-code.md) or apps from [our partners](https://stripe.partners/) to get started with Stripe and to do more with your Stripe account—no code required.

### Base URL

\`\`\`plaintext
https://api.stripe.com
\`\`\``,

  auth: `# Authentication

The Stripe API uses API keys to authenticate requests. You can view and manage your API keys in the [Stripe Dashboard](https://dashboard.stripe.com/apikeys).

Test mode secret keys start with \`sk_test_\` and have unrestricted access to their sandboxes. In live mode, you configure a [restricted API key](https://docs.stripe.com/keys#restricted-api-keys) (starts with \`rk_live_\`) with specific API permissions. Using a restricted API key with only a subset of API permissions limits the damage a bad actor could cause if they obtained the key. In both test mode and live mode, you can create as many restricted API keys as you need for different use cases or components of your application. We also create a live mode secret key (starts with \`sk_live_\`) that grants access to all Stripe resources. To protect your business, use restricted API keys in your production code.

Your API keys carry many privileges, so be sure to keep them secure! Do not share your secret API keys in public areas such as GitHub, client-side code, and so forth.

All API requests must be made over HTTPS. Calls made over plain HTTP will fail. API requests without authentication will also fail.

### Authenticated Request

\`\`\`bash
curl https://api.stripe.com/v1/charges \\
  -u sk_test_tR3Pybc...96tH8BS4VQ2u:
\`\`\``,

  errors: `# Errors

Stripe uses conventional HTTP response codes to indicate the success or failure of an API request. In general: Codes in the \`2xx\` range indicate success. Codes in the \`4xx\` range indicate an error that failed given the information provided (e.g., a required parameter was omitted, a charge failed, etc.). Codes in the \`5xx\` range indicate an error with Stripe's servers (these are rare).

Some \`4xx\` errors that could be handled programmatically (e.g., a card is declined) include an error code that briefly explains the error reported.

## Attributes

### code (nullable string)
For some errors that could be handled programmatically, a short string indicating the error code reported.

### decline_code (nullable string)
For card errors resulting from a card issuer decline, a short string indicating the card issuer's reason for the decline if they provide one.

### message (nullable string)
A human-readable message providing more details about the error. For card errors, these messages can be shown to your users.

### param (nullable string)
If the error is parameter-specific, the parameter related to the error. For example, you can use this to display a message near the correct form field.

### payment_intent (nullable dictionary)
The PaymentIntent object for errors returned on a request involving a PaymentIntent.

### type (enum)
The type of error returned. One of: api_error, card_error, idempotency_error, or invalid_request_error.`
};

// SECTION: Splits content (left) and widgets/code (right) into a unified grid
export function Section({ id, title, children }) {
  const contentChildren = [];
  const rightChildren = [];
  
  const { setIsChatOpen, setChatContext, setViewMode } = useContext(AppContext);
  const [copyState, setCopyState] = useState('idle'); // 'idle' | 'copying' | 'copied'

  React.Children.forEach(children, (child) => {
    if (child) {
      const isRightPane = 
        child.props?.render === 'CodeBlock' || 
        child.type?.name === 'CodeBlock' ||
        child.props?.render === 'CustomCode' ||
        child.type?.name === 'CustomCode' ||
        child.props?.render === 'BaseUrl' ||
        child.type?.name === 'BaseUrl' ||
        child.props?.render === 'ClientLibraries' ||
        child.type?.name === 'ClientLibraries' ||
        child.props?.render === 'StatusCodes' ||
        child.type?.name === 'StatusCodes' ||
        child.props?.render === 'ErrorTypes' ||
        child.type?.name === 'ErrorTypes' ||
        child.props?.render === 'RightPane' ||
        child.type?.name === 'RightPane' ||
        child.props?.render === 'InfoCard' ||
        child.type?.name === 'InfoCard' ||
        (child.props && child.props.className && child.props.className.includes('language-'));

      if (isRightPane) {
        rightChildren.push(child);
      } else {
        contentChildren.push(child);
      }
    }
  });

  const handleCopyForLlm = async () => {
    setCopyState('copying');
    
    // Copy the respective section's exact Markdown text
    const payload = SECTION_MARKDOWNS[id] || `# ${title}\nDocumentation content here...`;
    
    try {
      await navigator.clipboard.writeText(payload.trim());
      // Delay transition to 'copied' to show copying animation
      setTimeout(() => {
        setCopyState('copied');
        // Reset to 'idle' after 1.5s
        setTimeout(() => setCopyState('idle'), 1500);
      }, 450);
    } catch (err) {
      console.error('Failed to copy: ', err);
      setCopyState('idle');
    }
  };

  const handleAskAboutSection = () => {
    setChatContext('#' + id);
    setIsChatOpen(true);
  };

  const renderCopyButton = () => {
    if (copyState === 'copying') {
      return (
        <span className="flex items-center gap-1.5">
          <span className="w-3 h-3 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
          <span>Copying...</span>
        </span>
      );
    }
    if (copyState === 'copied') {
      return (
        <span className="flex items-center gap-1.5 text-emerald-500">
          <Check className="w-3.5 h-3.5 text-emerald-500" />
          <span className="font-semibold">Copied!</span>
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1.5">
        <svg aria-hidden="true" className="w-3.5 h-3.5 fill-current" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
          <path fillRule="evenodd" clipRule="evenodd" d="M4 6.375c0-.345.28-.625.625-.625h2.75a.625.625 0 1 1 0 1.25h-2.75A.625.625 0 0 1 4 6.375Zm0 2.25C4 8.28 4.28 8 4.625 8h2.75a.625.625 0 1 1 0 1.25h-2.75A.625.625 0 0 1 4 8.625Z" />
          <path fillRule="evenodd" clipRule="evenodd" d="M8.437 1.5A2 2 0 0 0 6.5 0h-1a2 2 0 0 0-1.937 1.5H3a2 2 0 0 0-2 2V10a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-.563ZM4.9 3.1h2.2V2a.6.6 0 0 0-.6-.6h-1a.6.6 0 0 0-.6.6v1.1ZM8 4.5H4a.5.5 0 0 1-.5-.5V2.9H3a.6.6 0 0 0-.6.6V10a.6.6 0 0 0 .6.6h6a.6.6 0 0 0 .6-.6V3.5a.6.6 0 0 0-.6-.6h-.5V4a.5.5 0 0 1-.5.5Z" />
        </svg>
        <span>Copy for LLM</span>
      </span>
    );
  };

  return (
    <section id={id} className="grid grid-cols-1 lg:grid-cols-12 border-b border-border-light dark:border-[#1F293D] transition-colors duration-200">
      
      {/* Center Description Column (58% width on desktop) */}
      <div className="lg:col-span-7 p-6 md:p-10 lg:p-12 bg-white dark:bg-[#0E1117] transition-colors duration-200">
        
        {/* Header row with Title */}
        <div className="flex justify-between items-baseline mb-6 border-b border-slate-100 dark:border-slate-800/40 pb-3 h-8">
          <h2 className="text-xl md:text-2xl font-bold font-sans tracking-tight text-[#0A2540] dark:text-white select-text">
            {title}
          </h2>
        </div>

        {/* Text descriptions, parameter lists, attributes */}
        <div className="prose prose-slate dark:prose-invert max-w-none text-sm leading-relaxed text-slate-600 dark:text-slate-300 space-y-4">
          {contentChildren}
        </div>
      </div>

      {/* Right Column: Code blocks, Client Libraries, and widgets (42% width on desktop) */}
      <div className="lg:col-span-5 p-6 md:p-10 lg:p-12 bg-slate-50 dark:bg-[#0E1117] lg:border-l border-border-light dark:border-[#1F293D] flex flex-col justify-start gap-6 select-text relative">
        
        {/* Actions Row aligned horizontally with header */}
        <div className="flex items-center lg:justify-end gap-3.5 text-[12px] font-semibold text-[#4F5B76] dark:text-slate-400 font-sans select-none h-8 border-b border-slate-100 dark:border-slate-800/40 lg:border-b-0 pb-3 lg:pb-0">
          {/* Ask about this section */}
          <div className="relative group flex items-center">
            <button 
              onClick={handleAskAboutSection}
              className="flex items-center gap-1.5 hover:text-[#0A2540] dark:hover:text-white transition-colors cursor-pointer focus:outline-none"
            >
              <svg aria-hidden="true" className="w-3.5 h-3.5 fill-current" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                <path d="M11.472 2.624a.25.25 0 0 0 .152-.152l.64-1.807A.246.246 0 0 1 12.5.499c.098 0 .196.055.236.166l.64 1.807a.25.25 0 0 0 .152.152l1.807.64c.111.04.166.138.166.236a.246.246 0 0 1-.166.236l-1.807.64a.25.25 0 0 0-.152.152l-.64 1.807a.246.246 0 0 1-.236.166.246.246 0 0 1-.236-.166l-.64-1.807a.25.25 0 0 0-.152-.152l-1.807-.64A.246.246 0 0 1 9.5 3.5c0-.098.055-.196.166-.236l1.807-.64Z" />
                <path fillRule="evenodd" clipRule="evenodd" d="m7 5.491-.56 1.58a2.25 2.25 0 0 1-1.37 1.37L3.492 9l1.58.56a2.25 2.25 0 0 1 1.37 1.37L7 12.508l.56-1.58a2.25 2.25 0 0 1 1.37-1.37L10.508 9l-1.58-.56a2.25 2.25 0 0 1-1.37-1.37L7 5.492Zm.707-2.496a.737.737 0 0 0-.707-.5.737.737 0 0 0-.707.5L5.026 6.57a.75.75 0 0 1-.456.456L.995 8.293a.737.737 0 0 0-.5.707c0 .294.167.589.5.707l3.575 1.267a.75.75 0 0 1 .456.456l1.267 3.575c.118.333.413.5.707.5a.737.737 0 0 0 .707-.5l1.267-3.575a.75.75 0 0 1 .456-.456l3.575-1.267a.737.737 0 0 0 .5-.707.737.737 0 0 0-.5-.707L9.43 7.026a.75.75 0 0 1-.456-.456L7.707 2.995Z" />
              </svg>
              <span>Ask about this section</span>
            </button>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2.5 hidden group-hover:block w-48 p-2 bg-[#2E3344] dark:bg-slate-900 text-white text-[11px] font-sans font-medium rounded-md shadow-lg text-center z-50 pointer-events-none whitespace-normal leading-normal select-none">
              Open the AI pane to ask a question about this section
            </div>
          </div>

          <div className="w-[1px] h-3 bg-slate-200 dark:bg-slate-800" />

          {/* Copy for LLM */}
          <div className="relative group flex items-center">
            <button 
              onClick={handleCopyForLlm}
              disabled={copyState !== 'idle'}
              className="flex items-center gap-1.5 hover:text-[#0A2540] dark:hover:text-white transition-colors cursor-pointer disabled:cursor-default focus:outline-none"
            >
              {renderCopyButton()}
            </button>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2.5 hidden group-hover:block w-40 p-2 bg-[#2E3344] dark:bg-slate-900 text-white text-[11px] font-sans font-medium rounded-md shadow-lg text-center z-50 pointer-events-none whitespace-normal leading-normal select-none">
              Copy page as Markdown
            </div>
          </div>

          <div className="w-[1px] h-3 bg-slate-200 dark:bg-slate-800" />

          {/* View as Markdown */}
          <div className="relative group flex items-center">
            <a 
              href="/api.md?lang=curl"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-[#0A2540] dark:hover:text-white transition-colors focus:outline-none"
            >
              <svg aria-hidden="true" className="w-3.5 h-3.5 fill-current" viewBox="0 0 208 128" xmlns="http://www.w3.org/2000/svg">
                <path clipRule="evenodd" fillRule="evenodd" d="M15 10a5 5 0 00-5 5v98a5 5 0 005 5h178a5 5 0 005-5V15a5 5 0 00-5-5zM0 15C0 6.716 6.716 0 15 0h178c8.284 0 15 6.716 15 15v98c0 8.284-6.716 15-15 15H15c-8.284 0-15-6.716-15-15z" />
                <path d="M30 98V30h20l20 25 20-25h20v68H90V59L70 84 50 59v39zm125 0l-30-33h20V30h20v35h20z" />
              </svg>
              <span>View as Markdown</span>
            </a>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2.5 hidden group-hover:block w-40 p-2 bg-[#2E3344] dark:bg-slate-900 text-white text-[11px] font-sans font-medium rounded-md shadow-lg text-center z-50 pointer-events-none whitespace-normal leading-normal select-none">
              View this page as plain text
            </div>
          </div>
        </div>

        <div className="lg:sticky lg:top-20 flex flex-col gap-6">
          {rightChildren.length > 0 ? (
            rightChildren
          ) : (
            <div className="text-xs text-slate-500 italic select-none">No samples available.</div>
          )}
        </div>
      </div>
    </section>
  );
}

// ENDPOINT: Method badge and URL
export function Endpoint({ method, path }) {
  const colors = {
    GET: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/40',
    POST: 'bg-blue-50 text-blue-700 dark:bg-blue-950/20 dark:text-blue-400 border-blue-200 dark:border-blue-900/40',
    DELETE: 'bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400 border-rose-200 dark:border-rose-900/40',
    PUT: 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-450 border-amber-200 dark:border-amber-900/40',
  };

  const badgeColor = colors[method?.toUpperCase()] || 'bg-slate-50 text-slate-700 border-slate-200';

  return (
    <div className="flex items-center gap-2.5 font-sans my-4 p-3 bg-slate-50 dark:bg-[#161920]/40 border border-border-light dark:border-[#1F293D] rounded-lg">
      <span className={`px-2 py-0.5 text-[10px] font-bold rounded border uppercase tracking-wider ${badgeColor} select-none`}>
        {method}
      </span>
      <span className="font-mono text-[13px] text-slate-800 dark:text-slate-200 font-semibold break-all select-all">
        {path}
      </span>
    </div>
  );
}

// PARAMETER: Detailed rendering of request parameters
export function Parameter({ name, type, required, children }) {
  return (
    <div className="py-3 border-t border-border-light dark:border-[#1F293D] first:border-t-0 select-text">
      <div className="flex items-baseline gap-2 flex-wrap mb-1">
        <span className="font-mono font-bold text-[13px] text-slate-800 dark:text-slate-100">{name}</span>
        <span className="text-xs font-mono text-slate-500 dark:text-slate-400">{type}</span>
        {required ? (
          <span className="text-[9px] uppercase font-bold tracking-wider text-rose-500 bg-rose-50 dark:bg-rose-950/20 px-1.5 py-0.2 rounded border border-rose-200/40 dark:border-rose-900/40 select-none">
            required
          </span>
        ) : (
          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-400 dark:text-slate-500 px-1.5 py-0.2 rounded border border-slate-200/40 dark:border-slate-800/40 select-none">
            optional
          </span>
        )}
      </div>
      <div className="text-[13px] text-slate-500 dark:text-slate-300 mt-1 leading-relaxed font-sans">
        {children}
      </div>
    </div>
  );
}

// ATTRIBUTES HEADER
export function AttributesHeader() {
  return (
    <div className="mt-8 mb-3 select-none">
      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 border-b border-border-light dark:border-[#1F293D] pb-1.5">
        Attributes
      </h3>
    </div>
  );
}

// CALLOUT: Info or warning alert boxes
export function Callout({ type, children }) {
  const isWarning = type === 'warning';
  const bgStyle = isWarning
    ? 'bg-amber-50 dark:bg-amber-950/15 border-amber-200 dark:border-amber-800/50 text-amber-800 dark:text-amber-300'
    : 'bg-blue-50 dark:bg-blue-950/15 border-blue-200 dark:border-blue-800/50 text-blue-800 dark:text-blue-300';

  const Icon = isWarning ? AlertTriangle : Info;
  const iconColor = isWarning ? 'text-amber-500' : 'text-blue-500';

  return (
    <div className={`flex gap-3.5 p-4 my-5 border rounded-lg text-[13px] leading-relaxed ${bgStyle}`}>
      <Icon className={`w-4.5 h-4.5 flex-shrink-0 mt-0.5 ${iconColor}`} />
      <div className="font-sans">{children}</div>
    </div>
  );
}

// CODEBLOCK: Syntax highlighting with copy actions and line numbers
export function CodeBlock({ content, language, title, children }) {
  const codeContent = content || (typeof children === 'string' ? children : '') || '';
  const ref = useRef(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (ref.current) {
      Prism.highlightElement(ref.current);
    }
  }, [codeContent, language]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(codeContent.trim());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const lines = codeContent.trim().split('\n');

  return (
    <div className="rounded-lg border border-slate-800 bg-[#161920] shadow-md overflow-hidden dark mb-6 select-none">
      {/* Code Header Bar */}
      <div className="flex justify-between items-center px-4 py-2 bg-[#0C0E12] border-b border-slate-800/80 text-[10px] text-slate-400 tracking-wide h-9 select-none">
        <div className="font-sans font-bold uppercase tracking-wider text-slate-350 select-none">
          {title || "AUTHENTICATED REQUEST"}
        </div>
        <div className="flex items-center gap-2.5 select-none">
          {/* Language Selector Selector dropdown mock */}
          <button className="flex items-center gap-1.5 bg-[#161920] border border-slate-800 px-2 py-1 rounded text-[10px] font-bold text-slate-300 hover:text-white transition-colors cursor-pointer select-none">
            <span>{language === 'bash' ? 'cURL' : (language === 'js' ? 'Node.js' : language)}</span>
            <ChevronDown className="w-3 h-3 text-slate-450" />
          </button>
          
          {/* Copy Action button */}
          <button
            onClick={handleCopy}
            className="hover:text-white text-slate-400 transition-colors flex items-center justify-center p-1.5 rounded hover:bg-slate-800 cursor-pointer focus:outline-none"
            title="Copy Code"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Explain using AI Button */}
          <button
            onClick={() => alert("Stripe AI explanation is not available for this sample code.")}
            className="hover:text-white text-slate-400 transition-colors flex items-center justify-center p-1.5 rounded hover:bg-slate-800 cursor-pointer focus:outline-none"
            title="Explain using AI"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#A5B4FC]" />
          </button>
        </div>
      </div>

      {/* Code Body with Stripe-like non-selectable line numbers */}
      <div className="p-4 bg-[#161920] font-mono text-[13px] overflow-x-auto leading-relaxed">
        <table className="w-full border-collapse">
          <tbody>
            {lines.map((line, idx) => (
              <tr key={idx} className="flex">
                {/* Line Index column */}
                <td className="w-6 text-right pr-3 text-slate-600 select-none font-sans font-medium">
                  {idx + 1}
                </td>
                {/* Code segment */}
                <td className="flex-1 whitespace-pre select-text text-slate-200">
                  {line}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// BASEURL: Base url widget box
export function BaseUrl() {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText("https://api.stripe.com");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full rounded-lg overflow-hidden border border-slate-200 dark:border-slate-800/60 shadow-sm select-none mb-6">
      {/* Header bar */}
      <div className="bg-[#4F566B] dark:bg-[#20242F] px-4 py-2.5 flex justify-between items-center text-[11px] font-semibold tracking-wider text-slate-200 dark:text-slate-400 uppercase select-none">
        <span>BASE URL</span>
        <div className="flex items-center gap-3">
          {/* Click to Copy */}
          <button 
            onClick={handleCopy} 
            className="hover:text-white text-slate-350 dark:text-slate-400 transition-colors flex items-center gap-1 cursor-pointer focus:outline-none relative"
            title="Copy Base URL"
          >
            {copied ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
          </button>
          
          {/* Explain using AI Tooltip */}
          <div className="relative group flex items-center">
            <button className="text-slate-350 dark:text-slate-450 hover:text-white transition-colors cursor-pointer focus:outline-none">
              <Sparkles className="w-4 h-4 text-[#A5B4FC]" />
            </button>
            {/* Tooltip */}
            <div className="absolute right-0 bottom-full mb-2.5 hidden group-hover:block w-64 p-3 bg-slate-900 dark:bg-slate-950 text-slate-250 text-[11.5px] font-sans rounded-md shadow-2xl z-50 leading-relaxed border border-slate-800">
              <div className="font-bold mb-1 text-indigo-400 flex items-center gap-1 font-sans">
                <Sparkles className="w-3 h-3 text-indigo-450" />
                Stripe AI Explanation
              </div>
              <p className="m-0 text-slate-300 font-sans text-xs">
                This is the main endpoint entrypoint URL for all Stripe API requests. Make sure all backend HTTP calls target this endpoint.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* URL content bar */}
      <div className="bg-[#2E3344] dark:bg-[#0A0D14] px-4 py-3 text-left">
        <span className="font-mono text-sm md:text-[14px] text-slate-100 select-all tracking-wide block">
          https://api.stripe.com
        </span>
      </div>
    </div>
  );
}

// CLIENTLIBRARIES: Interactive mock for SDK libraries
export function ClientLibraries() {
  const libraries = [
    { 
      name: 'Ruby', 
      logo: (
        <svg viewBox="4 4 28 28" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
          <path d="M23.476 5.076c2.78.481 3.569 2.382 3.51 4.373L27 9.42l-1.251 16.398-16.266 1.114h.014c-1.35-.057-4.36-.18-4.497-4.388l1.508-2.75 2.584 6.037.461 1.075 2.571-8.382-.027.006.014-.028 8.484 2.71-1.28-4.978-.907-3.575 8.085-.522-.564-.467-5.804-4.732 3.354-1.871-.003.01zM9.703 9.65c3.264-3.238 7.477-5.152 9.095-3.52 1.615 1.63-.097 5.597-3.367 8.833-3.266 3.238-7.428 5.256-9.042 3.628-1.62-1.63.041-5.7 3.31-8.938l.004-.003z" fill="#D91505" />
        </svg>
      )
    },
    { 
      name: 'Python', 
      logo: (
        <svg viewBox="0 0 256 255" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid" width="22" height="22">
          <path d="M126.916.072c-64.832 0-60.784 28.115-60.784 28.115l.072 29.128h61.868v8.745H41.631S.145 61.355.145 126.77c0 65.417 36.21 63.097 36.21 63.097h21.61v-30.356s-1.165-36.21 35.632-36.21h61.362s34.475.557 34.475-33.319V33.97S194.67.072 126.916.072zM92.802 19.66a11.12 11.12 0 0111.13 11.13 11.12 11.12 0 01-11.13 11.13 11.12 11.12 0 01-11.13-11.13 11.12 11.12 0 0111.13-11.13z" fill="#3372a7" />
          <path d="M128.757 254.126c64.832 0 60.784-28.115 60.784-28.115l-.072-29.127H127.6v-8.745h86.441s41.486 4.705 41.486-60.712c0-65.416-36.21-63.096-36.21-63.096h-21.61v30.355s1.165 36.21-35.632 36.21h-61.362s-34.475-.557-34.475 33.32v56.013s-5.235 33.897 62.518 33.897zm34.114-19.586a11.12 11.12 0 01-11.13-11.13 11.12 11.12 0 0111.13-11.131 11.12 11.12 0 0111.13 11.13 11.12 11.12 0 01-11.13 11.13z" fill="#ffd235" />
        </svg>
      )
    },
    { 
      name: 'PHP', 
      logo: (
        <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
          <g fill="#6181B6" fillRule="evenodd">
            <path d="M9.762 14.509h-1.18l-.643 3.31h1.047c.695 0 1.213-.132 1.553-.393.34-.262.569-.698.687-1.311.115-.588.063-1.002-.155-1.244-.218-.241-.653-.362-1.308-.362z" />
            <path d="M16 8.86c-8.284 0-15 3.533-15 7.89s6.716 7.891 15 7.891c8.284 0 15-3.533 15-7.891s-6.716-7.89-15-7.89zm-4.075 9.314a3.034 3.034 0 01-1.146.688c-.42.135-.956.205-1.606.205H7.696l-.408 2.102H5.564l1.538-7.908h3.312c.996 0 1.723.261 2.18.785.458.523.595 1.253.412 2.19-.07.371-.198.729-.38 1.059a3.57 3.57 0 01-.702.879zm5.03.893l.679-3.498c.079-.398.049-.67-.085-.814-.134-.145-.42-.218-.859-.218h-1.365l-.88 4.532h-1.71l1.538-7.909h1.708l-.408 2.103h1.522c.959 0 1.619.167 1.983.5s.472.876.328 1.625l-.715 3.68h-1.736zm9.496-2.83a3.477 3.477 0 01-.381 1.058 3.57 3.57 0 01-.701.879 3.05 3.05 0 01-1.147.688c-.42.135-.956.205-1.607.205H21.14l-.409 2.103H19.01l1.537-7.908h3.312c.996 0 1.722.262 2.18.785.457.522.596 1.252.413 2.19z" fillRule="nonzero" />
            <path d="M23.207 14.509H22.03l-.645 3.31h1.047c.696 0 1.214-.132 1.553-.393.34-.262.568-.698.688-1.311.115-.588.062-1.002-.156-1.244-.217-.241-.655-.362-1.309-.362z" />
          </g>
        </svg>
      )
    },
    { 
      name: 'Java', 
      logo: (
        <svg viewBox="0 0 256 346" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid" width="20" height="20">
          <path d="M82.55 267.47s-13.2 7.68 9.4 10.28c27.37 3.12 41.35 2.67 71.51-3.04 0 0 7.93 4.97 19 9.28-67.6 28.98-153.01-1.68-99.9-16.52m-8.26-37.81s-14.81 10.96 7.8 13.3c29.23 3.01 52.32 3.26 92.27-4.44 0 0 5.53 5.6 14.22 8.67-81.75 23.9-172.8 1.89-114.3-17.53" fill="#5382A1" />
          <path d="M143.94 165.51c16.66 19.19-4.38 36.45-4.38 36.45s42.3-21.84 22.88-49.19c-18.15-25.5-32.06-38.17 43.27-81.86 0 0-118.24 29.53-61.77 94.6" fill="#E76F00" />
          <path d="M233.36 295.44s9.77 8.05-10.75 14.28c-39.03 11.82-162.44 15.39-196.72.47-12.32-5.36 10.79-12.8 18.06-14.37 7.58-1.64 11.91-1.33 11.91-1.33-13.7-9.66-88.58 18.95-38.03 27.15 137.85 22.35 251.3-10.07 215.53-26.2M88.9 190.48s-62.77 14.9-22.23 20.32c17.12 2.3 51.25 1.78 83.03-.89 25.98-2.19 52.07-6.85 52.07-6.85s-9.16 3.93-15.8 8.45c-63.74 16.77-186.88 8.97-151.43-8.18 29.98-14.5 54.36-12.85 54.36-12.85m112.6 62.94c64.8-33.67 34.84-66.03 13.93-61.67-5.12 1.07-7.4 2-7.4 2s1.9-2.99 5.53-4.28c41.37-14.54 73.19 42.9-13.36 65.65 0 0 1-.9 1.3-1.7" fill="#5382A1" />
          <path d="M162.44.37s35.89 35.9-34.04 91.1c-56.07 44.28-12.78 69.53-.02 98.38-32.73-29.53-56.75-55.53-40.64-79.72C111.4 74.6 176.92 57.39 162.44.37" fill="#E76F00" />
          <path d="M95.27 344.67c62.2 3.98 157.71-2.21 159.97-31.64 0 0-4.35 11.15-51.4 20.01-53.09 10-118.57 8.83-157.4 2.42 0 0 7.95 6.58 48.83 9.2" fill="#5382A1" />
        </svg>
      )
    },
    { 
      name: 'Node.js', 
      logo: (
        <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
          <path d="M15.516 28.952a2.09 2.09 0 01-1.002-.263l-3.17-1.883c-.478-.262-.24-.358-.096-.405.644-.215.763-.263 1.43-.644.072-.048.167-.024.239.024l2.432 1.454c.095.048.214.048.286 0l9.513-5.507c.095-.048.143-.143.143-.263v-10.99c0-.12-.048-.215-.143-.263L15.635 4.73c-.096-.048-.215-.048-.286 0l-9.513 5.483c-.096.048-.143.167-.143.262v10.991c0 .096.047.215.143.263l2.599 1.502c1.406.715 2.288-.12 2.288-.954V11.428a.29.29 0 01.286-.286h1.216a.29.29 0 01.287.286v10.848c0 1.884-1.026 2.98-2.814 2.98-.548 0-.977 0-2.193-.596L5 23.23A2.012 2.012 0 014 21.49V10.497c0-.715.381-1.383 1.001-1.74l9.513-5.508a2.128 2.128 0 012.003 0l9.513 5.508a2.012 2.012 0 011.001 1.74V21.49c0 .716-.381 1.383-1.001 1.74l-9.513 5.508a2.44 2.44 0 01-1.001.215zm2.932-7.558c-4.172 0-5.03-1.907-5.03-3.529a.29.29 0 01.286-.286h1.24c.142 0 .262.096.262.239.19 1.263.739 1.883 3.266 1.883 2.003 0 2.861-.453 2.861-1.526 0-.62-.238-1.073-3.362-1.383-2.598-.262-4.22-.834-4.22-2.908 0-1.931 1.622-3.076 4.34-3.076 3.051 0 4.553 1.05 4.744 3.338a.385.385 0 01-.072.215c-.047.047-.119.095-.19.095h-1.24a.28.28 0 01-.262-.215c-.286-1.31-1.025-1.74-2.98-1.74-2.194 0-2.456.763-2.456 1.335 0 .691.31.906 3.266 1.288 2.933.381 4.315.93 4.315 2.98-.023 2.098-1.74 3.29-4.768 3.29z" fill="#89D42C" />
        </svg>
      )
    },
    { 
      name: 'Go', 
      logo: (
        <svg viewBox="2 2 30 30" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
          <g fill="#00ACD7" fillRule="evenodd">
            <path d="M3.35 13.5c-.06 0-.07-.04-.05-.08l.3-.4c.04-.03.11-.06.17-.06h5.17c.06 0 .07.04.05.08l-.25.38c-.03.04-.1.09-.15.09l-5.24-.02zm-2.19 1.33c-.06 0-.07-.03-.04-.08l.3-.39c.03-.04.1-.07.16-.07h6.6c.07 0 .1.04.08.09l-.12.34c-.01.06-.07.1-.13.1H1.16zm3.51 1.33c-.06 0-.08-.04-.05-.09l.2-.36c.04-.04.1-.09.15-.09h2.9c.06 0 .09.05.09.1l-.03.35c0 .06-.06.1-.1.1l-3.16-.01zm15.04-2.93l-2.43.64c-.22.06-.24.07-.42-.15-.22-.24-.38-.4-.69-.55a2.52 2.52 0 00-2.62.22 3.08 3.08 0 00-1.48 2.75 2.27 2.27 0 001.96 2.28c.98.13 1.81-.22 2.46-.96l.4-.53h-2.8c-.3 0-.38-.2-.28-.44.19-.45.54-1.2.74-1.58a.4.4 0 01.36-.23h5.28c-.03.4-.03.78-.09 1.18-.16 1.04-.55 2-1.19 2.84a6.04 6.04 0 01-4.13 2.46 5.13 5.13 0 01-3.9-.96A4.55 4.55 0 019.04 17c-.18-1.58.28-3 1.24-4.25a6.43 6.43 0 014.05-2.5 5 5 0 013.84.7c.77.5 1.32 1.2 1.69 2.05.08.13.02.2-.15.24z" />
            <path d="M24.5 21.25a5.44 5.44 0 01-3.53-1.28 4.55 4.55 0 01-1.56-2.8 5.53 5.53 0 011.17-4.37 6.08 6.08 0 014.06-2.42 5.38 5.38 0 014.13.74 4.51 4.51 0 012.04 3.23 5.6 5.6 0 01-1.67 4.91 6.64 6.64 0 01-3.47 1.86c-.4.07-.79.08-1.16.13zm3.46-5.86c-.02-.19-.02-.33-.05-.48A2.39 2.39 0 0024.96 13a3.17 3.17 0 00-2.54 2.52 2.39 2.39 0 001.33 2.74c.8.34 1.6.3 2.37-.1a3.17 3.17 0 001.84-2.76z" fill-rule="nonzero" />
          </g>
        </svg>
      )
    },
    { 
      name: '.NET', 
      logo: (
        <svg viewBox="2 2 28 28" xmlns="http://www.w3.org/2000/svg" width="22" height="22">
          <g fill="#1384C8" fillRule="evenodd">
            <path d="M11.68 13.26c1 3.07 1.38 8.54 4.31 8.54.23 0 .45-.03.68-.07-2.67-.62-2.98-6.03-4.6-8.83l-.39.36" />
            <path d="M12.06 12.9c1.63 2.8 1.94 8.21 4.6 8.83.22-.04.43-.1.64-.17-2.4-1.17-3.06-6.42-4.9-8.95l-.34.29" />
            <path d="M14.4 11.23a5.17 5.17 0 00-2.48.82c.17.17.33.35.48.56.62-.51 1.23-.9 1.84-1.12.23-.09.46-.15.69-.2a2.12 2.12 0 00-.53-.06m4.76 9.25c.25-.2.5-.4.74-.64-1.02-3.05-1.38-8.6-4.34-8.6-.2 0-.42.02-.63.06 2.69.67 3.03 6.52 4.23 9.18" />
            <path d="M14.93 11.3a2.12 2.12 0 00-.53-.07h1.17c-.22 0-.43.03-.64.07m4.18 9.83a4.37 4.37 0 01-.33-.36c-.5.35-1 .62-1.48.8a2.28 2.28 0 001.02.23c.55 0 .99-.07 1.36-.25-.2-.1-.4-.25-.57-.42m-4.87-9.64c2.4 1.26 2.62 6.96 4.54 9.28l.38-.29c-1.2-2.66-1.54-8.51-4.23-9.18-.23.04-.46.1-.69.19" />
            <path d="M12.4 12.6c1.84 2.54 2.5 7.79 4.9 8.96.49-.17.98-.44 1.48-.79-1.92-2.32-2.13-8.02-4.54-9.28-.61.23-1.22.6-1.84 1.12m-1.9.58c-.3.65-.59 1.51-.94 2.64.7-1 1.42-1.87 2.12-2.57-.1-.3-.2-.57-.31-.82-.3.22-.58.47-.87.75" />
            <path d="M11.62 12.26l-.25.18c.1.25.21.52.3.82l.4-.36a5.07 5.07 0 00-.45-.64" />
            <path d="M11.93 12.05l-.3.2c.15.2.3.42.43.65l.34-.3c-.15-.2-.3-.38-.47-.55M28.35 11c-1.36 5.25-4.2 9.47-6.59 10.54l-.13.05h-.02l-.04.02h-.01l-.06.03h-.03l-.03.02h-.02l-.03.02-.05.01h-.02l-.04.02h-.02l-.04.01-.04.01c.1.04.22.06.34.06 2.26 0 4.54-4.05 8.31-10.79h-1.48zm-19.29.45h.01l.04-.02h.01l.01-.01.04-.01.09-.04h.01l.04-.01h.02l.03-.02h.02l.12-.03h.02l.04-.01h.01l.04-.02.08-.01h.07l.04-.01h.02l.08-.02h-.24c-2.55 0-6.06 4.72-7.64 10.84h.3c.51-.9.96-1.76 1.38-2.56 1.1-4.33 3.36-7.29 5.36-8.07m1.44 1.74c.29-.28.58-.53.87-.75a4.1 4.1 0 00-.21-.4 4.9 4.9 0 00-.66 1.15" />
            <path d="M10.7 11.48c.17.14.32.34.46.57l.13-.15a2.55 2.55 0 00-.58-.42M3.7 19.52c2.32-4.47 3.42-7.3 5.36-8.07-2 .78-4.25 3.74-5.36 8.07" />
            <path d="M11.3 11.9l-.14.14.2.4.26-.18c-.1-.13-.21-.25-.33-.36M4.75 22.06h-.08l-.1.01c2.35-.06 3.42-1.24 3.96-2.95.4-1.3.73-2.38 1.03-3.3a46.74 46.74 0 00-2.97 4.9c-.48.88-1.21 1.26-1.84 1.34" />
            <path d="M4.75 22.06A2.43 2.43 0 006.6 20.7c1-1.85 1.98-3.5 2.97-4.88.35-1.13.65-1.99.94-2.64-1.96 1.86-3.93 4.97-5.75 8.87M3.7 19.52c-.42.8-.87 1.66-1.38 2.56h.89c.12-.9.28-1.75.49-2.56" />
            <path d="M9.82 11.25H9.8l-.04.01h-.02l-.03.01h-.02l-.07.02H9.6a.3.3 0 01-.04 0l-.02.01h-.03l-.02.01-.12.03h-.02l-.03.02H9.3l-.04.02h-.01l-.09.03-.04.01-.01.01-.04.01-.01.01c-1.95.77-3.05 3.6-5.37 8.07-.2.81-.37 1.66-.49 2.56h1.47l.04-.01h.05c1.81-3.9 3.78-7.01 5.74-8.88.22-.48.43-.86.66-1.14a2.17 2.17 0 00-.45-.56l-.03-.02-.03-.01-.03-.02h-.03l-.02-.02-.05-.02h-.03a.73.73 0 01-.03-.02l-.03-.01-.05-.02-.06-.02h-.02l-.05-.02h-.01a1.84 1.84 0 00-.13-.03h-.02l-.05-.01h-.01l-.07-.01h-.14m13.21 2.64c-.44 1.44-.8 2.62-1.12 3.6a38.91 38.91 0 003.58-6.27c-1.34.43-2.05 1.39-2.46 2.68m-1.08 7.54l-.19.09c2.39-1.07 5.23-5.29 6.6-10.54h-.28c-3.13 5.6-4.14 9.33-6.13 10.45m-1.56-.47c.52-.64.94-1.71 1.52-3.49a18.1 18.1 0 01-2 2.34l-.01.01c.15.44.3.83.49 1.14M20.39 20.98a2.13 2.13 0 01-.71.57 2.01 2.01 0 00.85.24h.41l.04-.02h.08l.12-.03c-.31-.11-.57-.38-.8-.76M16 21.8a3.57 3.57 0 001.3-.24 2.29 2.29 0 001.02.24H16z" />
            <path d="M18.32 21.8c.55 0 .99-.07 1.36-.25a2.01 2.01 0 00.85.24h.13-2.34zm2.34 0h.15l.04-.01h.1l.05-.02h.06l.12-.03c.1.04.22.06.34.06h-.86zm-.76-1.96a10.73 10.73 0 01-1.12.93c.1.13.22.25.33.36.18.17.37.31.57.42l.14-.07c.2-.12.4-.29.57-.5-.18-.32-.34-.7-.49-1.14M27.2 11h-1.38l-.23.01-.1.22a38.91 38.91 0 01-3.58 6.26c-.58 1.77-1 2.85-1.52 3.48.22.38.48.65.79.76h.04l.04-.02h.02l.04-.01h.02l.05-.02.03-.01.02-.01.03-.01.03-.01.06-.02h.01l.04-.02h.02l.12-.06h.01l.19-.1c1.99-1.1 3-4.85 6.13-10.44h-.88zm-17.3.25h.05l.08.01.06.02h.02l.13.03.06.02h.01a.93.93 0 01.07.02l.05.02h.02l.04.02.02.01.05.02.03.01.03.02h.03l.03.02c.22.11.42.26.61.43a2 2 0 01.22-.2 2.4 2.4 0 00-1.61-.45" />
            <path d="M11.3 11.9c.1.1.22.23.32.36.1-.08.2-.14.3-.2a3.2 3.2 0 00-.41-.36c-.08.06-.15.12-.22.2m-1.39-.65l.19-.01c.54 0 1 .17 1.42.46.44-.34.96-.47 1.7-.47H9.66l.24.02" />
            <path d="M13.2 11.23c-.73 0-1.25.13-1.7.47.15.1.3.22.43.35.6-.38 1.2-.64 1.8-.75.23-.04.45-.07.67-.07h-1.2zm8.7 6.27c.32-.98.68-2.16 1.13-3.6.4-1.28 1.12-2.25 2.46-2.67l.1-.22c-2.18.14-3.2 1.25-3.72 2.9-.9 2.87-1.44 4.74-1.97 5.92a17.5 17.5 0 002-2.34" />
          </g>
        </svg>
      )
    }
  ];

  return (
    <div className="w-full rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800/60 shadow-sm text-left select-none mb-6">
      {/* Top Section */}
      <div className="bg-white dark:bg-[#161920] p-5">
        <div className="text-[11px] font-bold tracking-wider text-slate-450 dark:text-slate-500 uppercase mb-5 select-none">
          CLIENT LIBRARIES
        </div>
        
        {/* Logos Grid */}
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-3">
          {libraries.map((lib, idx) => (
            <button
              key={idx}
              onClick={() => alert(`Viewing documentation examples for: ${lib.name}`)}
              className="flex flex-col items-center text-center cursor-pointer hover:opacity-85 active:scale-95 transition-all duration-150 bg-transparent focus:outline-none"
            >
              <div className="w-8 h-8 flex items-center justify-center mb-1 flex-shrink-0">
                {lib.logo}
              </div>
              <span className="text-[12px] font-semibold text-slate-650 dark:text-slate-300 font-sans mt-0.5">
                {lib.name}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="bg-[#F8FAFC] dark:bg-[#0D1016] border-t border-slate-200/60 dark:border-slate-800/40 p-4 px-5">
        <p className="text-[13px] leading-relaxed text-slate-550 dark:text-slate-400 font-sans m-0">
          By default, the Stripe API Docs demonstrate using <code className="font-mono px-1.5 py-0.2 bg-slate-200/60 dark:bg-slate-800 text-slate-650 dark:text-slate-350 rounded text-[12px]">curl</code> to interact with the API over HTTP. Select one of our official <span onClick={() => alert("Redirecting to client libraries...")} className="text-[#635BFF] dark:text-[#8F85FF] hover:underline font-medium cursor-pointer">client libraries</span> to see examples in code.
        </p>
      </div>
    </div>
  );
}

// STATUSCODES: Table detailing HTTP responses
export function StatusCodes() {
  const codes = [
    { code: '200', status: 'OK', desc: 'Everything worked as expected.' },
    { code: '400', status: 'Bad Request', desc: 'The request was unacceptable, often due to missing a required parameter.' },
    { code: '401', status: 'Unauthorized', desc: 'No valid API key provided.' },
    { code: '402', status: 'Request Failed', desc: 'The parameters were valid but the request failed.' },
    { code: '403', status: 'Forbidden', desc: "The API key doesn't have permissions to perform the request." },
    { code: '404', status: 'Not Found', desc: "The requested resource doesn't exist." },
    { code: '409', status: 'Conflict', desc: 'The request conflicts with another request (perhaps due to using the same idempotency key).' },
    { code: '424', status: 'External Dependency Failed', desc: "The request couldn't be completed due to a failure in a dependency." },
    { code: '429', status: 'Too Many Requests', desc: 'Too many requests hit the API too quickly. We recommend an exponential backoff.' },
    { code: '500, 502, 503, 504', status: 'Server Errors', desc: "Something went wrong on Stripe's end. (These are rare.)" },
  ];

  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#161920] p-4 text-left shadow-sm overflow-hidden select-none">
      <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-3 tracking-wider">
        HTTP Status Code Summary
      </div>
      
      <div className="overflow-x-auto">
        <table className="status-table">
          <thead>
            <tr>
              <th>Code</th>
              <th>Status</th>
              <th>Description</th>
            </tr>
          </thead>
          <tbody>
            {codes.map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-100/50 dark:hover:bg-slate-800/20 transition-colors">
                <td className="font-mono font-bold text-slate-700 dark:text-slate-300 whitespace-nowrap">
                  {item.code}
                </td>
                <td className="font-semibold text-slate-605 dark:text-slate-350">
                  {item.status}
                </td>
                <td className="text-slate-500 dark:text-slate-400">
                  {item.desc}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ERRORTYPES: Details different API errors
export function ErrorTypes() {
  const types = [
    {
      name: 'api_error',
      desc: "API errors cover any other type of problem (e.g., a temporary problem with Stripe's servers), and are extremely uncommon."
    },
    {
      name: 'card_error',
      desc: "Card errors are the most common type of error you should expect to handle. They result when the user enters a card that can't be charged."
    },
    {
      name: 'idempotency_error',
      desc: "Idempotency errors occur when an Idempotency-Key is re-used on a request that does not match the first request's API endpoint and parameters."
    },
    {
      name: 'invalid_request_error',
      desc: "Invalid request errors arise when your request has invalid parameters."
    }
  ];

  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#161920] p-4 text-left shadow-sm select-none">
      <div className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-3.5 tracking-wider">
        Error Types
      </div>
      
      <div className="space-y-3.5">
        {types.map((type, idx) => (
          <div key={idx} className="flex gap-3 flex-wrap sm:flex-nowrap items-start py-2.5 border-b border-slate-200/50 dark:border-slate-800/40 last:border-b-0 last:pb-0">
            <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-350 border border-slate-200 dark:border-slate-800/50 font-semibold select-all">
              {type.name}
            </span>
            <p className="text-[11px] leading-normal text-slate-500 dark:text-slate-400">
              {type.desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

// FEEDBACK: Was this section helpful? buttons
export function Feedback() {
  return (
    <div className="flex gap-3 items-center text-[14px] font-sans text-[#4F5B76] dark:text-slate-400 mt-8 pt-4 border-t border-slate-100 dark:border-slate-800/40 select-none">
      <span>Was this section helpful?</span>
      <div className="flex gap-2.5">
        <button 
          onClick={() => alert("Thank you for your feedback!")}
          className="text-[#635BFF] dark:text-[#8F85FF] hover:underline font-medium cursor-pointer"
        >
          Yes
        </button>
        <button 
          onClick={() => alert("Thank you for your feedback!")}
          className="text-[#635BFF] dark:text-[#8F85FF] hover:underline font-medium cursor-pointer"
        >
          No
        </button>
      </div>
    </div>
  );
}

// RIGHTPANE: Container to render elements in the right pane
export function RightPane({ children }) {
  return (
    <div className="prose prose-slate dark:prose-invert max-w-none text-xs leading-relaxed text-slate-600 dark:text-slate-300 space-y-4 font-sans">
      {children}
    </div>
  );
}

// INFOCARD: Bordered widget cards
export function InfoCard({ title, children }) {
  return (
    <div className="rounded-lg border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#161920] p-4 text-left shadow-sm select-none">
      {title && (
        <h4 className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-2 tracking-wider">
          {title}
        </h4>
      )}
      <div className="text-xs text-slate-550 dark:text-slate-400 leading-normal font-sans">
        {children}
      </div>
    </div>
  );
}

// COLLAPSIBLEPARAMETERS: Collapsible list of parameters (accordion)
export function CollapsibleParameters({ children }) {
  const childrenArray = React.Children.toArray(children);
  const [openStates, setOpenStates] = useState(() => childrenArray.map(() => false));

  const toggleAll = () => {
    const anyOpen = openStates.some(x => x);
    setOpenStates(openStates.map(() => !anyOpen));
  };

  const toggleIndex = (idx) => {
    setOpenStates(openStates.map((val, i) => i === idx ? !val : val));
  };

  const isAnyOpen = openStates.some(x => x);

  return (
    <div className="mt-6 border-t border-slate-100 dark:border-slate-800/40 pt-4">
      {/* Master Toggle Header */}
      <div className="flex justify-between items-center mb-4 select-none">
        <span className="text-xs font-bold text-slate-800 dark:text-white uppercase tracking-wider font-sans">
          More
        </span>
        <button
          onClick={toggleAll}
          className="text-[11px] font-sans font-medium text-slate-500 dark:text-slate-400 hover:text-slate-705 dark:hover:text-slate-300 border border-slate-200 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-[#161920] px-2 py-0.5 rounded cursor-pointer transition-colors shadow-sm"
        >
          {isAnyOpen ? 'Collapse all' : 'Expand all'}
        </button>
      </div>

      {/* Accordion list */}
      <div className="space-y-0.5">
        {childrenArray.map((child, idx) => {
          // Allow custom Markdoc nodes that render Parameter
          const isParam = child && (child.type?.name === 'Parameter' || child.props?.render === 'Parameter');
          if (!isParam) {
            return child;
          }

          const { name, type, required, children: desc } = child.props;
          const isOpen = openStates[idx];
          const ChevronIcon = isOpen ? ChevronDown : ChevronRight;

          return (
            <div 
              key={idx} 
              className="border-b border-slate-100 dark:border-[#1F293D]/30 py-3 last:border-b-0"
            >
              {/* Accordion Trigger Header */}
              <button
                onClick={() => toggleIndex(idx)}
                className="w-full flex items-center gap-2 text-left cursor-pointer hover:opacity-85 select-none focus:outline-none"
              >
                <ChevronIcon className="w-3.5 h-3.5 text-slate-450 dark:text-slate-500 flex-shrink-0" />
                <span className="font-mono font-bold text-[13px] text-slate-800 dark:text-slate-150">
                  {name}
                </span>
                <span className="text-xs font-mono text-slate-500 dark:text-slate-450">
                  {type}
                </span>
                {required && (
                  <span className="text-[9px] uppercase font-bold tracking-wider text-rose-500 bg-rose-50 dark:bg-rose-950/20 px-1.5 py-0.2 rounded border border-rose-200/40 dark:border-rose-900/40">
                    required
                  </span>
                )}
              </button>

              {/* Accordion Collapsible Panel */}
              {isOpen && (
                <div className="text-[13px] text-slate-550 dark:text-slate-400 mt-2 pl-5 leading-relaxed font-sans select-text">
                  {desc}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

