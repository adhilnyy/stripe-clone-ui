{% section id="intro" title="API Reference" %}
The Stripe API is organized around [REST](https://en.wikipedia.org/wiki/Representational_State_Transfer). Our API has predictable resource-oriented URLs, accepts [form-encoded](https://en.wikipedia.org/wiki/POST_(HTTP)#Use_for_submitting_web_forms) request bodies, returns [JSON-encoded](https://www.json.org/) responses, and uses standard HTTP response codes, authentication, and verbs.

You can use the Stripe API in [sandboxes](https://docs.stripe.com/sandboxes) without affecting your live data or interacting with banking networks. The API key that you use to [authenticate](https://docs.stripe.com/keys) the request determines whether the request runs in live mode or in a sandbox. Sandboxes support all [v2 APIs](https://docs.stripe.com/api/v2). Test mode sandboxes support some [v2 APIs](https://docs.stripe.com/api/v2).

The Stripe API doesn't support bulk updates. You can work on only one object per request.

The Stripe API differs for every account as we release new [versions](https://docs.stripe.com/api/versioning) and tailor functionality. [Log in](https://dashboard.stripe.com/login) to see docs with your test key and data.

{% feedback /%}

{% right_pane %}
### Just getting started?
Check out our [development quickstart](https://docs.stripe.com/get-started/development-environment.md) guide.

### Not a developer?
Use Stripe's [no-code options](https://docs.stripe.com/payments/no-code.md) or apps from [our partners](https://stripe.partners/) to get started with Stripe and to do more with your Stripe account—no code required.
{% /right_pane %}

{% base_url /%}

{% client_libraries /%}
{% /section %}

{% section id="auth" title="Authentication" %}
The Stripe API uses [API keys](https://docs.stripe.com/keys) to authenticate requests. You can view and manage your API keys in [the Stripe Dashboard](https://dashboard.stripe.com).

Test mode secret keys start with `sk_test_` and have unrestricted access to their sandboxes. In live mode, you configure a [restricted API key](https://docs.stripe.com/keys#restricted-keys) (starts with `rk_live_`) with specific API permissions. Using a restricted API key with only a subset of API permissions limits the damage a bad actor could cause if they obtained the key. In both test mode and live mode, you can create as many restricted API keys as you need for different use cases or components of your application. We also create a live mode secret key (starts with `sk_live_`) that grants access to all Stripe resources. To protect your business, use restricted API keys instead.

Your API keys carry many privileges. Follow [best practices](https://docs.stripe.com/keys#best-practices) to keep your keys safe. Don't embed secret or restricted API keys in source code or client-side applications. Instead, use your server platform's secrets vault to provide keys to your server-side applications. If your platform doesn't offer a secrets vault, set your keys in environment variables.

The Stripe API authenticates requests using [HTTP Basic Auth](https://en.wikipedia.org/wiki/Basic_access_authentication). Provide your API key as the basic auth username value. You don't need to provide a password.

If you need to authenticate using bearer auth (for example, for a cross-origin request), use `-H "Authorization: Bearer sk_test_tR3Pybc...96tH88S4VQ2u"` instead of `-u sk_test_tR3Pybc...96tH88S4VQ2u`.

Make all API requests over [HTTPS](https://en.wikipedia.org/wiki/HTTPS). Calls made over plain HTTP fail. API requests without authentication also fail.

{% code language="bash" title="AUTHENTICATED REQUEST" %}
curl https://api.stripe.com/v1/charges \
  -u sk_test_tR3PYbcVNZZ796tH88S4VQ2u:
# The colon prevents curl from asking for a password.
{% /code %}

{% info_card title="YOUR API KEY" %}
A sample test API key is included in all the examples here, so you can test any example right away. Do not submit any personally identifiable information in requests made with this key.

To test requests using your account, replace the sample API key with your actual API key or [sign in](https://dashboard.stripe.com/login).
{% /info_card %}
{% /section %}

{% section id="errors" title="Errors" %}
Stripe uses conventional HTTP response codes to indicate the success or failure of an API request. In general: Codes in the `2xx` range indicate success. Codes in the `4xx` range indicate an error that failed given the information provided (e.g., a required parameter was omitted, a charge failed, etc.). Codes in the `5xx` range indicate an error with Stripe's servers (these are rare).

Some `4xx` errors that could be handled programmatically (e.g., a card is declined) include an error code that briefly explains the error reported.

{% feedback /%}

{% attributes_header /%}

{% parameter name="code" type="nullable string" %}
For some errors that could be handled programmatically, a short string indicating the error code reported.
{% /parameter %}

{% parameter name="decline_code" type="nullable string" %}
For card errors resulting from a card issuer decline, a short string indicating the card issuer's reason for the decline if they provide one.
{% /parameter %}

{% parameter name="message" type="nullable string" %}
A human-readable message providing more details about the error. For card errors, these messages can be shown to your users.
{% /parameter %}

{% parameter name="param" type="nullable string" %}
If the error is parameter-specific, the parameter related to the error. For example, you can use this to display a message near the correct form field.
{% /parameter %}

{% parameter name="payment_intent" type="nullable dictionary" %}
The PaymentIntent object for errors returned on a request involving a PaymentIntent.
{% /parameter %}

{% parameter name="type" type="enum" %}
The type of error returned. One of: `api_error`, `card_error`, `idempotency_error`, or `invalid_request_error`.
{% /parameter %}

{% collapsible_parameters %}
  {% parameter name="advice_code" type="nullable string" %}
  For card errors resulting from a card issuer decline, a short string indicating [how to proceed with an error](https://docs.stripe.com/error-handling) if they provide one.
  {% /parameter %}

  {% parameter name="charge" type="nullable string" %}
  For card errors, the ID of the failed charge.
  {% /parameter %}

  {% parameter name="doc_url" type="nullable string" %}
  A URL to more information about the [error code](https://docs.stripe.com/error-codes) reported.
  {% /parameter %}

  {% parameter name="network_advice_code" type="nullable string" %}
  For card errors resulting from a card issuer decline, a 2-digit code which indicates the advice given to merchant by the card network on how to proceed with an error.
  {% /parameter %}

  {% parameter name="network_decline_code" type="nullable string" %}
  For payments declined by the network, an alphanumeric code which indicates the reason the payment failed.
  {% /parameter %}

  {% parameter name="payment_method" type="nullable dictionary" %}
  The [PaymentMethod](https://docs.stripe.com/api/payment_methods) object for errors returned on a request involving a PaymentMethod.
  {% /parameter %}

  {% parameter name="payment_method_type" type="nullable string" %}
  If the error is specific to the type of payment method, the payment method type that had a problem. This field is only populated for invoice-related errors.
  {% /parameter %}

  {% parameter name="request_log_url" type="nullable string" %}
  A URL to the request log entry in your dashboard.
  {% /parameter %}

  {% parameter name="setup_intent" type="nullable dictionary" %}
  The [SetupIntent](https://docs.stripe.com/api/setup_intents) object for errors returned on a request involving a SetupIntent.
  {% /parameter %}

  {% parameter name="source" type="nullable dictionary" %}
  The [source](https://docs.stripe.com/api/sources) object for errors returned on a request involving a source.
  {% /parameter %}
{% /collapsible_parameters %}

{% status_codes /%}

{% error_types /%}
{% /section %}
