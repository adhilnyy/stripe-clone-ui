import React, { useState, useEffect, useContext } from 'react';
import { Sidebar } from './Sidebar';
import { Menu, ChevronDown, Sun, Moon } from 'lucide-react';
import { AppContext } from '../App';

export function Layout({ children, currentActiveId, setActiveId, isDarkMode, toggleTheme, isChatOpen }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { setIsChatOpen } = useContext(AppContext);

  // Keyboard shortcut listener to toggle chatbot pane with Cmd + I / Ctrl + I
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'i') {
        e.preventDefault();
        setIsChatOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [setIsChatOpen]);

  // Scroll spy setup
  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '-30% 0px -50% 0px',
      threshold: 0.05
    };

    const handleIntersection = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveId(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(handleIntersection, observerOptions);
    const sections = document.querySelectorAll('section[id]');
    sections.forEach((section) => observer.observe(section));

    return () => {
      sections.forEach((section) => observer.unobserve(section));
    };
  }, [children, setActiveId]);

  const handleNavClick = (id) => {
    setActiveId(id);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 64;
      const elementPosition = element.getBoundingClientRect().top + window.scrollY;
      const offsetPosition = elementPosition - (window.innerWidth < 1024 ? headerOffset : 0);

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="min-h-screen font-sans bg-white dark:bg-[#0E1117] flex text-slate-800 dark:text-slate-200 transition-colors duration-200">
      
      {/* LEFT PANE: Sidebar */}
      <Sidebar 
        isOpen={sidebarOpen} 
        setIsOpen={setSidebarOpen} 
        currentActiveId={currentActiveId}
        onNavClick={handleNavClick}
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
        onAskAiClick={() => setIsChatOpen(true)}
      />

      {/* RIGHT PANE: Header & Main Column grid (Adjust right padding if chatbot is open) */}
      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${isChatOpen ? 'lg:pr-[400px]' : ''}`}>
        
        {/* Mobile Header (sticky on mobile, hidden on desktop) */}
        <header className="sticky top-0 z-30 lg:hidden flex items-center justify-between px-4 py-3 bg-white/95 dark:bg-[#0E1117]/95 border-b border-border-light dark:border-[#1F293D] backdrop-blur transition-colors">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-1.5 rounded-md text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-900 border border-border-light dark:border-slate-800"
            >
              <Menu className="w-5 h-5" />
            </button>
            <a href="/" className="flex items-center gap-1.5 hover:opacity-85 transition-opacity">
              {/* Stripe Logo Wordmark */}
              <svg className="h-4.5 w-11 flex-shrink-0" viewBox="0 0 360 150" xmlns="http://www.w3.org/2000/svg">
                <path className="fill-[#0A2540] dark:fill-white transition-colors" fillRule="evenodd" d="M360 77.4c0 2.4-.2 7.6-.2 8.9h-48.9c1.1 11.8 9.7 15.2 19.4 15.2 9.9 0 17.7-2.1 24.5-5.5v20c-6.8 3.8-15.8 6.5-27.7 6.5-24.4 0-41.4-15.2-41.4-45.3 0-25.4 14.4-45.6 38.2-45.6 23.7 0 36.1 20.2 36.1 45.8zm-49.4-9.5h25.8c0-11.3-6.5-16-12.6-16-6.3 0-13.2 4.7-13.2 16zm-63.5-36.3c17.5 0 34 15.8 34.1 44.8 0 31.7-16.3 46.1-34.2 46.1-8.8 0-14.1-3.7-17.7-6.3l-.1 28.3-25 5.3V33.2h22l1.3 6.2c3.5-3.2 9.8-7.8 19.6-7.8zm-6 68.9c9.2 0 15.4-10 15.4-23.4 0-13.1-6.3-23.3-15.4-23.3-5.7 0-9.3 2-11.9 4.9l.1 37.1c2.4 2.6 5.9 4.7 11.8 4.7zm-71.3-74.8V5.3L194.9 0v20.3l-25.1 5.4zm0 7.6h25.1v87.5h-25.1V33.3zm-26.9 7.4c5.9-10.8 17.6-8.6 20.8-7.4v23c-3.1-1.1-13.1-2.5-19 5.2v59.3h-25V33.3h21.6l1.6 7.4zm-50-29.1l-.1 21.7h19v21.3h-19v35.5c0 14.8 15.8 10.2 19 8.9v20.3c-3.3 1.8-9.3 3.3-17.5 3.3-14.8 0-25.9-10.9-25.9-25.7l.1-80.1 24.4-5.2zM25.3 58.7c0 11.2 38.1 5.9 38.2 35.7 0 17.9-14.3 28.2-35.1 28.2-8.6 0-18-1.7-27.3-5.7V93.1c8.4 4.6 19 8 27.3 8 5.6 0 9.6-1.5 9.6-6.1 0-11.9-38-7.5-38-35.1 0-17.7 13.5-28.3 33.8-28.3 8.3 0 16.5 1.3 24.8 4.6v23.5c-7.6-4.1-17.2-6.4-24.8-6.4-5.3 0-8.5 1.5-8.5 5.4z" />
              </svg>
              
              {/* API Wordmark */}
              <svg className="h-2 w-5 flex-shrink-0" viewBox="0 0 260 113" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path className="fill-[#635BFF] dark:fill-[#8F85FF]" d="M42.056 0.991992L0.248 113H23.024L31.916 88.976H78.092L86.984 113H110.228L68.264 0.991992H42.056ZM54.848 26.42L70.76 69.476H39.092L54.848 26.42ZM150.43 71.816H173.362C199.102 71.816 215.17 59.492 215.17 36.404C215.17 13.16 199.102 0.991992 173.362 0.991992H127.498V113H150.43V71.816ZM150.43 52.316V20.492H172.114C185.53 20.492 192.394 26.264 192.394 36.404C192.394 46.388 185.53 52.316 172.114 52.316H150.43ZM259.423 0.991992H236.491V113H259.423V0.991992Z" />
              </svg>
            </a>
          </div>
          
          <button
            onClick={toggleTheme}
            className="relative w-8.5 h-5 rounded-full bg-slate-200 dark:bg-slate-800 transition-colors duration-250 flex items-center shadow-inner focus:outline-none cursor-pointer"
          >
            <div 
              className={`absolute w-4.5 h-4.5 rounded-full bg-white dark:bg-[#1A1F36] shadow-md flex items-center justify-center transition-all duration-200 border border-slate-250/60 dark:border-slate-700/60 ${
                isDarkMode ? 'left-3.5' : 'left-0'
              }`}
            >
              {isDarkMode ? (
                <Moon className="w-2.5 h-2.5 text-indigo-500 fill-indigo-500" />
              ) : (
                <Sun className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
              )}
            </div>
          </button>
        </header>

        {/* Desktop Header matching screenshot */}
        <div className="hidden lg:flex items-center justify-end gap-6 px-10 py-4 bg-white dark:bg-[#0E1117] border-b border-border-light dark:border-[#1F293D] select-none transition-colors duration-200 text-[13px]">
          <button className="flex items-center gap-1 hover:opacity-80 transition-opacity cursor-pointer font-sans font-semibold text-[#0A2540] dark:text-slate-200">
            <span>2026-06-24.dahlia</span>
            <ChevronDown className="w-3.5 h-3.5 text-[#0A2540] dark:text-slate-400" />
          </button>
          
          <button className="flex items-center gap-1 text-[#635BFF] dark:text-[#8F85FF] hover:opacity-80 transition-opacity font-sans font-semibold cursor-pointer">
            <span>API Reference</span>
            <ChevronDown className="w-3.5 h-3.5 text-[#635BFF] dark:text-[#8F85FF]" />
          </button>
          
          <a href="#docs" className="text-[#635BFF] dark:text-[#8F85FF] hover:opacity-80 transition-opacity font-sans font-semibold">
            Docs
          </a>
          
          <a href="#support" className="text-[#635BFF] dark:text-[#8F85FF] hover:opacity-80 transition-opacity font-sans font-semibold">
            Support
          </a>
          
          <a href="#signin" className="text-[#635BFF] dark:text-[#8F85FF] hover:opacity-80 transition-opacity flex items-center gap-0.5 font-sans font-semibold">
            <span>Sign in</span>
            <span className="text-xs ml-0.5">→</span>
          </a>
        </div>

        {/* Scrollable Document Area */}
        <main className="flex-1 flex flex-col relative">
          {children}
        </main>
      </div>
    </div>
  );
}
