export const config = {
  tags: {
    section: {
      render: 'Section',
      children: [
        'paragraph',
        'heading',
        'list',
        'tag',
        'code',
        'endpoint',
        'parameter',
        'callout',
        'base_url',
        'client_libraries',
        'status_codes',
        'error_types',
        'attributes_header',
        'feedback',
        'right_pane',
        'info_card',
        'collapsible_parameters'
      ],
      attributes: {
        id: { type: String },
        title: { type: String }
      }
    },
    endpoint: {
      render: 'Endpoint',
      attributes: {
        method: { type: String, required: true },
        path: { type: String, required: true }
      }
    },
    parameter: {
      render: 'Parameter',
      attributes: {
        name: { type: String, required: true },
        type: { type: String, required: true },
        required: { type: Boolean, default: false }
      }
    },
    callout: {
      render: 'Callout',
      attributes: {
        type: { type: String, default: 'info' } // info, warning
      }
    },
    code: {
      render: 'CodeBlock',
      attributes: {
        language: { type: String, default: 'bash' },
        title: { type: String }
      }
    },
    base_url: {
      render: 'BaseUrl'
    },
    client_libraries: {
      render: 'ClientLibraries'
    },
    status_codes: {
      render: 'StatusCodes'
    },
    error_types: {
      render: 'ErrorTypes'
    },
    attributes_header: {
      render: 'AttributesHeader'
    },
    feedback: {
      render: 'Feedback'
    },
    right_pane: {
      render: 'RightPane'
    },
    info_card: {
      render: 'InfoCard',
      attributes: {
        title: { type: String }
      }
    },
    collapsible_parameters: {
      render: 'CollapsibleParameters',
      children: ['parameter']
    }
  },
  nodes: {
    fence: {
      render: 'CodeBlock',
      attributes: {
        content: { type: String },
        language: { type: String }
      }
    }
  }
};
